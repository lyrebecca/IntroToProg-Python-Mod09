# ------------------------------------------------------------------------ #
# Title: Assignment 09
# Description: Working with Modules

# ChangeLog (Who,When,What):
# RRoot,1.1.2030,Created started script
# RRoot,1.1.2030,Added pseudo-code to start assignment 9
# RebeccaLy,9.4.2020,Modified code to complete assignment 9
# ------------------------------------------------------------------------ #
# Imports modules 
import ProcessingClasses
import IOClasses

# Main Body of Script  ---------------------------------------------------- #
# TODO: Add Data Code to the Main body

# Load data from file into a list of employee objects when script starts
listTable = ProcessingClasses.FileProcessor.read_data_from_file("EmployeeData.txt")

# Show user a menu of options
while(True):
    IOClasses.EmployeeIO.print_menu_items()

    # Get user's menu option choice
    choice = IOClasses.EmployeeIO.input_menu_options()
    # Show user current data in the list of employee objects
    if choice == "1":
        IOClasses.EmployeeIO.print_current_list_items(listTable)
    # Let user add data to the list of employee objects
    elif choice == "2":
        listTable.append(IOClasses.EmployeeIO.input_employee_data())
    # let user save current data to file
    elif choice == "3":
        ProcessingClasses.FileProcessor.save_data_to_file("EmployeeData.txt",listTable)
    # Let user exit program
    elif choice == "4":
        exit(0)


# Main Body of Script  ---------------------------------------------------- #
